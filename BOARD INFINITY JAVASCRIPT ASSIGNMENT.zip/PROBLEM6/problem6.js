/*
PROBLEM 6 =====>  
Write a code to get an integer N and print the sum of  values from 1 to N. 
Input Description:  A single line contains an integer N. 
Output Description:  Print the sum of values from 1 to N. 
Sample Input :  10  
Sample Output : 55  
*/

const number =10;
let sum = 0;
for (let i = 1; i <= number; i++) {
    sum += i;
}
console.log('The sum of values from 1 to N is:', sum);