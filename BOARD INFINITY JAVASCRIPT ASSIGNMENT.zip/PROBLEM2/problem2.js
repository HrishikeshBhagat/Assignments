/*   
PROBLEM 2  
You are given with a number "N", find its cube. 
Input Description:  A positive integer is provided as an input. 
Output Description:  Find the cube of the number. 
Sample Input :  2  
Sample Output :  8 
*/

const number = 2;
let cube = Math.pow(number, 3); //Math.pow(x,y) returns the value of x to the power of y

console.log(`The cube of ${number} is ${cube}.`);