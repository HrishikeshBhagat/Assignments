/*PROBLEM 13 
Ajay is given a series(In example).he gone through the series but unable to understand 
it properly,he has hired you.Your task is to understand the series and print the series 
2,6,12,20,30... .You are given with a number ‘n’. Find the nth number of series. 
Input Description: 
You will be given a number ‘n’
Output Description: 
Print the nth number of series
Sample Input :
5 
Sample Output : 
30
*/


var n = 5;
for (let i = 1; i <= n; i++) {
    var b =( (i * i) + i); //1*1= 1+1 =2 //2*2=4+2=6 //3*3=9+3=12 //4*4=16+4=20
}
console.log(b);