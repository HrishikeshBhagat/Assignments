/*
ROBLEM 15 
You are given a postfix expression. Evaluate the given expression and print the result. 
Input Description: 
The first line of the input is a string N, containing operators and numbers seperated by 
the single space which forms a postfix expression.
Output Description: 
Evaluate the post expression and print the result.
Sample Input :
5 3 1 * + 9 -
Sample Output :
-1
*/

let exp = "5 3 1 * + 9 -";

function evaluatePostfix(exp) {     // create a stack
    let stack = [];

    // Scan all characters one by one
    for (let i = 0; i < exp.length; i++) {
        let c = exp[i];

        if (c == ' ') {
            continue;
        }

        // If the scanned character is an
        // operand (number here),extract the number. Push it to the stack.
        else if (c >= '0' && c <= '9') {
            let n = 0;

            // extract the characters and
            // store it in num
            while (c >= '0' && c <= '9') {
                n = n * 10 + (c - '0');
                i++;
                c = exp[i];
            }
            i--;

            // push the number in stack
            stack.push(n);
        }

        // If the scanned character is
        // an operator, pop two elements from stack apply the operator
        else {
            let val1 = stack.pop();
            let val2 = stack.pop();

            switch (c) {
                case '+':
                    stack.push(val2 + val1);
                    break;

                case '-':
                    stack.push(val2 - val1);
                    break;

                case '/':
                    stack.push(parseInt(val2 / val1, 10));
                    break;

                case '*':
                    stack.push(val2 * val1);
                    break;
            }
        }
    }
    return stack.pop();
}
console.log(evaluatePostfix(exp));
