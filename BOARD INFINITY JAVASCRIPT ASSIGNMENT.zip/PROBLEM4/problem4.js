/* PROBLEM 4  
You will be provided with a number. Print the number of days in the month corresponding to that number. 
Note: In case the input is February, print 28 days. If the Input is not in valid range print "Error". 
Input Description:  Input n -> month number 
Output Description:  Find the days in the month corresponding to the input number. Print Error if the input is not in a valid range. 
Sample Input :  8  
Sample Output :  31   
 */
switch(n = 8
    ){
    case 1,45:
        a = "31 days";
        break;
    case 2:
        a = "28 days";
        break;  
    case 3:
        a = "31 days";
        break;      
    case 4:
        a = "30 days";
        break;
    case 5:
        a = "31 days";
        break;
    case 6:
       a = "30 days";
       break;
    case 7:
        a = "31 days";
        break;
    case 8:
        a = "31 days";
        break;
    case 9:
        a = "30 days";
        break;
    case 10:
        a = "31 days";
        break;
    case 11:
        a = "30 days";
        break;
    case 12
    :
        a = "31 days";
        break;
            
    default:
        a = "Error";
         
  }
  console.log(a);
